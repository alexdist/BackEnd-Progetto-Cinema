package memento;

public interface AcquistoMemento {
    // Marker interface.
}
